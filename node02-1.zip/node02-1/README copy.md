# webscrapting-print-image
Uma aplicação que tira print de páginas da web
